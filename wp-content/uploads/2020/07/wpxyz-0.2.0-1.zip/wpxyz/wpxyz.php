<?php
/*
 * Plugin Name: 小宇宙
 * Plugin URI: https://www.wpxyz.com.cn/
 * Description:
 * Author: 魏星
 * Author URI: https://weixingv.com/
 * Version: 0.2.0
 */

define('XYZ_VERSION', '0.2.0');
define('XYZ_PATH', plugin_dir_path( __FILE__ ) ) ;
define('XYZ_URL', plugin_dir_url( __FILE__ ) ) ;
define('XYZ_STATIC_URL', XYZ_URL.'static/' );
define('XYZ_CSS_URL', XYZ_STATIC_URL.'css/' );
define('XYZ_JS_URL', XYZ_STATIC_URL.'js/' );
define('XYZ_IMG_URL', XYZ_STATIC_URL.'img/' );
define('XYZ_API_URL', 'https://www.wpxyz.com.cn/wp-admin/admin-ajax.php');

# 核心函数框架
include "lib/functions.php";

# codestar 后台框架
include "lib/framework/framework.php";

# 调用页面
include "page/index.php";

if(xyz_is_actived()){

# seo功能
include "extand/seo/index.php";

# 添加代码
include "extand/addcode/index.php";

# WP优化
include "extand/switcher/switcher.php";

# 代码高亮
include "extand/codehighlight/index.php";

# 代码高亮
include "extand/shortcode/src_box.php";


}