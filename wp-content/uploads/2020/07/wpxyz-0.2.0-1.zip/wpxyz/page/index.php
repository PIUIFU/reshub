<?php

// 防止本文件直接被访问
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

function xyz_info() {

    add_menu_page(
        '小宇宙',
        '小宇宙',
        'administrator',
        'wpxyz',
        '',
        XYZ_IMG_URL.'/xyz.png',
        2
    );
    add_submenu_page( 'wpxyz', '小宇宙', '小宇宙', 'administrator', 'wpxyz', function(){
      include "home.php";
    });


}
add_action( 'admin_menu', 'xyz_info',1 );