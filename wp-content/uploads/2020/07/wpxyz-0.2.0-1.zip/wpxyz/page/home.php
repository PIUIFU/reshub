<?php
wp_enqueue_style('uikit-style'          ,XYZ_STATIC_URL."uikit/css/uikit.min.css",   array(), false, 'all');
wp_enqueue_script( 'uikit'        ,XYZ_STATIC_URL."uikit/js/uikit.min.js",array() , false , false );
wp_enqueue_script( 'icon'        ,XYZ_STATIC_URL."uikit/js/uikit-icons.js",array() , false , false );


// 防止本文件直接被访问
if (!defined('ABSPATH')) {
    exit;
}
if(!xyz_is_actived()){
    $img_url = XYZ_IMG_URL.'qrcode.jpg';
    $site_url = get_bloginfo('url');

    echo <<<EOT

<div id="wpbody-content">
	<div class="csf csf-options csf-theme-light" data-slug="seo_setting" data-unique="seo_setting">
		<div class="csf-container">
			<form method="post" action="" enctype="multipart/form-data" id="csf-form" autocomplete="off">
				<input type="hidden" class="csf-section-id" name="csf_transient[section]" value="1"><input type="hidden" id="csf_options_nonceseo_setting" name="csf_options_nonceseo_setting" value="7013af9374"><input type="hidden" name="_wp_http_referer" value="/wp-admin/admin.php?page=seo_setting">
				<div class="csf-header">
					<div class="csf-header-inner">
						<div class="csf-header-left">
							<h1>
							<style>
h4{font-size:13px!important;}ul{padding-left: 0px}
							</style>
							<img src="https://www.wpxyz.com.cn/wp-content/plugins/wpxyz/static/img/xyz-blue.png" style="height:2em;vertical-align: middle">
							<span style="font-size:1rem;opacity: 0.8">小宇宙插件</span>
							<small> Prod by 小宇宙工作室</small></h1>
						</div>
						
						<div class="clear">
						</div>
					</div>
				</div>
				<div class="csf-wrapper csf-show-all">
					<div class="csf-content">
						<div class="csf-sections uk-height-large">
						
						
						
						<div class="card uk-position-relative">
						    <div class="logo">
						        <img style="opacity: 0.99;width: 3em;top: -4px" class="uk-position-relative" src="https://www.wpxyz.com.cn/wp-content/plugins/wpxyz/static/img/xyz-big.png" alt="">
						        WordPress小宇宙
                            </div>
						    <div class="status uk-position-absolute uk-position-center-right uk-margin-right">暂未激活</div>   
						    <div class="num uk-position-absolute uk-position-bottom-left">NO.00001</div>   
                        </div>
                       
                          
                        <p class="uk-text-center">
                            <a href="#activation" uk-toggle type="submit" class="button button-primary" style="background: #0f33ffd4!important;color: #ffffff!important;box-shadow: none;border-radius: 50px;text-shadow: none;" >立即激活</a>
                        </p>
                        <div id="activation" uk-modal>
    <div class="uk-modal-dialog uk-modal-body uk-margin-large-top">
        <button class="uk-modal-close-outside " type="button" uk-close></button>
                <h2 class="uk-modal-title uk-text-center">激活步骤</h2>

				<p class="uk-text-meta uk-text-center">微信扫码关注公众号，并发送“小宇宙”获取激活码</p>
				<p class="uk-text-center">
					<img src="https://www.wpxyz.com.cn/wp-content/plugins/wpxyz/static/img/qrcode.jpg" style="height: 160px;width: 160px">
				</p>
				<p class="uk-text-center">
					<input id="license_input" class="uk-input uk-form-width-medium uk-form-small" type="text" placeholder="输入激活码">
				</p>
				<p class="uk-text-center">
                    <button id="license_submit" type="submit" class="button button-primary" style="background: #0f33ffd4!important;color: #ffffff!important;box-shadow: none;border-radius: 50px;text-shadow: none;" >立即激活</button>
				</p>
    </div>
</div>

		<script>
			var SiteAJAXUrl = "$site_url/wp-admin/admin-ajax.php";

			function SuccessNotification(messageContent) {
				UIkit.notification.closeAll();
				UIkit.notification({
					message: "<svg  class=\"icon uk-margin-small-right\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2648\" width=\"32\" height=\"32\"><path d=\"M512 0.006C229.233 0.006 0.006 229.233 0.006 512S229.233 1023.994 512 1023.994 1023.994 794.767 1023.994 512 794.767 0.006 512 0.006z m269.355 390.731L468.122 703.974c-9.763 9.763-22.56 14.645-35.355 14.645-12.796 0-25.592-4.882-35.355-14.645l-0.028-0.029-154.739-154.737c-19.526-19.526-19.527-51.185 0-70.71 19.526-19.526 51.184-19.527 70.711 0l119.411 119.41 277.878-277.88c19.525-19.526 51.184-19.527 70.711 0 19.526 19.525 19.526 51.183-0.001 70.709z\" fill=\"#54d25c\" p-id=\"2649\"></path></svg>" + messageContent,
					pos: 'bottom-center',
					status: 'success'
				});
			}

			function FailNotification(messageContent) {
				UIkit.notification.closeAll();
				UIkit.notification({
					message: "<svg class=\"icon uk-margin-small-right\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"6923\" width=\"32\" height=\"32\"><path d=\"M512 1024c-283.574857 0-512-228.425143-512-512s228.425143-512 512-512 512 228.425143 512 512-228.425143 512-512 512z\" fill=\"#BB1629\" p-id=\"6924\"></path><path d=\"M559.396571 598.747429c-3.218286 40.594286-25.526857 59.538286-47.542857 59.538285-16.310857 0 0 0 0 0-20.845714-4.534857-37.083429-14.848-44.251428-55.881143L438.857143 218.916571C438.857143 180.370286 479.378286 146.285714 513.755429 146.285714S585.142857 181.979429 585.142857 220.452571l-25.746286 378.294858zM512 731.428571a73.142857 73.142857 0 1 0 0 146.285715 73.142857 73.142857 0 0 0 0-146.285715\" fill=\"#FFFFFF\" p-id=\"6925\"></path></svg>" + messageContent,
					pos: 'bottom-center',
					status: 'danger'
				});
			}

			jQuery(document).on('click', '#license_submit', function(event) {

				InputLicense = jQuery('#license_input').val();

				if(InputLicense.replace(/\s+/g, "").length <= 0) {
					FailNotification('请输入验证码');
					return false
				}
				jQuery.ajax({
						url: SiteAJAXUrl,
						type: 'POST',
						dataType: 'json',
						data: {
							action: 'check_init',
							code: InputLicense
						}
					})
					.done(function(data) {
						if(data.code == 200) {
							SuccessNotification('小宇宙成功激活');
							window.location.reload();
						} else {
							FailNotification(data.msg);
						}
					})
			});
		</script>
                        <style>
                        .card{
                            width: 500px;border-radius: 8px;background-color: #fff;background-image: radial-gradient(circle farthest-corner at 45px 45px, rgba(185,185,185,0.7) 0%, #cecece 100%);background-repeat: no-repeat;height: 260px;margin: 50px auto;box-sizing: border-box;padding: 20px;overflow: hidden;color: #fff;box-shadow: 0 5px 60px -10px rgba(0,0,0,0.35);transition: all 0.6s;
                        }
                        .status{
                            border-radius: 12px;
                            font-size: 2.53em;
                            opacity: 0.5;
                        }
                        .num{
                        margin-left: 26px;
                        margin-bottom: 16px;
                        letter-spacing: 0.3em;
                        }
                        </style>
						
						</div>
						<div class="clear">
						</div>
					</div>
					<div class="csf-nav-background">
					</div>
				</div>
			</form>
		</div>
		<div class="clear">
		</div>
		<span style="opacity: 0.4;display: inline-block;margin-top: 0.8em">©&nbsp;西安市小宇宙网络工作室</span>
	</div>
</div>

EOT;

}else{
    $wx_img_url = XYZ_IMG_URL.'qrcode.jpg';
    $qq_img_url = XYZ_IMG_URL.'qq.jpg';
    $site_url = get_bloginfo('url');
    echo <<<EOT

<div id="wpbody-content">
	<div class="csf csf-options csf-theme-light" data-slug="seo_setting" data-unique="seo_setting">
		<div class="csf-container">
			<form method="post" action="" enctype="multipart/form-data" id="csf-form" autocomplete="off">
				<input type="hidden" class="csf-section-id" name="csf_transient[section]" value="1"><input type="hidden" id="csf_options_nonceseo_setting" name="csf_options_nonceseo_setting" value="7013af9374"><input type="hidden" name="_wp_http_referer" value="/wp-admin/admin.php?page=seo_setting">
				<div class="csf-header">
					<div class="csf-header-inner">
						<div class="csf-header-left">
							<h1>

							<img src="https://www.wpxyz.com.cn/wp-content/plugins/wpxyz/static/img/xyz-blue.png" style="height:2em;vertical-align: middle">
							<span style="font-size:1rem;opacity: 0.8">小宇宙插件</span>
							<small> Prod by 小宇宙工作室</small></h1>
						</div>
						
						<div class="clear">
						</div>
					</div>
				</div>
				<div class="csf-wrapper csf-show-all">
					<div class="csf-content">
						<div class="csf-sections uk-height-large">
						
						<div class="card uk-position-relative">
						    <div class="logo">
						        <img style="opacity: 0.99;width: 3em;top: -4px" class="uk-position-relative" src="https://www.wpxyz.com.cn/wp-content/plugins/wpxyz/static/img/xyz-big.png" alt="">
						        WordPress小宇宙
                            </div>
						    <div class="status uk-position-absolute uk-position-center-right uk-margin-right">已激活</div>   
						    <div class="num uk-position-absolute uk-position-bottom-left">NO.00001</div>  
						
                        </div>
                       
                          
                        <p class="uk-text-center">
                            <a href="https://www.wpxyz.com.cn/support" uk-toggle type="submit" class="button button-primary" 
                            style="background: #0f33ffd4!important;color: #ffffff!important;box-shadow: none;
                            border-radius: 50px;text-shadow: none;" >技术支持</a>
                        </p>

                        <style>
                        .card{
                            width: 500px;border-radius: 8px;background-color: #fff;
                            background-image: radial-gradient(circle farthest-corner at 45px 45px, rgba(12,12,12,0.7) 0%, #000000 100%);
                            background-repeat: no-repeat;
                            height: 260px;margin: 50px auto;box-sizing: border-box;padding: 20px;overflow: hidden;color: #fff;box-shadow: 0 5px 60px -10px rgba(0,0,0,0.35);transition: all 0.6s;
                        }
                        .card > *{
                            z-index: 2;
                        }

                        .status{
                            border-radius: 12px;
                            font-size: 1.2em;
                            background: #ff419e;
                            display: inline-block;
                            padding:0.4em 1em;
                        }
                        .num{
                            margin-left: 26px;
                            margin-bottom: 16px;
                            letter-spacing: 0.3em;
                            font-weight: 400;
                            color: #ffd600;
                        }
                        
                        
                        
                        </style>
						
						</div>
						<div class="clear">
						</div>
					</div>
					<div class="csf-nav-background">
					</div>
				</div>
			</form>
		</div>
		<div class="clear">
		</div>
		<span style="opacity: 0.4;display: inline-block;margin-top: 0.8em">©&nbsp;西安市小宇宙网络工作室</span>
	</div>
</div>


EOT;

}
?>
