<?php
//对象转数组
function object_array($array){
    if(is_object($array))
    {
        $array = (array)$array;
    }
    if(is_array($array))
    {
        foreach($array as $key=>$value)
        {
            $array[$key] = object_array($value);
        }
    }
    return $array;
}
function wpxyz_enqueue_sources(){
    wp_enqueue_style ( 'site'      ,XYZ_CSS_URL."wpxyz.css"        ,array(), false, 'all');
  //wp_enqueue_script( 'site'      ,XYZ_JS_URL."wpxyz.js"          ,array(), false, true);
}
add_action('wp_enqueue_scripts' , 'wpxyz_enqueue_sources' , 2);

// 添加设置选项到小宇宙插件下
function xyz_add_submenu($name,$slug,$info='Provided by 小宇宙插件'){
    CSF::createOptions( $slug, array(
        'framework_title'         => '<style>h4{font-size:13px!important;}ul{padding-left: 0px}</style><img src="'.XYZ_IMG_URL.'xyz-blue.png" style="height:2em;vertical-align: middle">
                                  <span style="font-size:1rem;opacity: 0.8">'.$name.'</span>
                                  <small> '.$info.'</small>',
        'framework_class'         => '',
        'menu_title'              => $name,
        'menu_slug'               => $slug,
        'menu_type'               => 'submenu',
        'menu_parent'             => 'wpxyz',
        'menu_capability'         => 'manage_options',
        'menu_position'           =>  null,
        'menu_hidden'             =>  false,
        'show_sub_menu'           => true,
        'show_network_menu'       => true,
        'show_in_customizer'      => false,
        'show_search'             => false,
        'show_reset_all'          => false,
        'show_reset_section'      => false,
        'show_footer'             => false,
        'show_all_options'        => false,
        'sticky_header'           => false,
        'save_defaults'           => true,
        'ajax_save'               => true,


        // footer
        'footer_after'            => '<span style="opacity: 0.4;display: inline-block;margin-top: 0.8em">&copy;&nbsp;西安市小宇宙网络工作室</span> ',
        'footer_credit'           => ' ',

        'database'                => '',
        'transient_time'          => 0,
        'contextual_help'         => array(),
        'contextual_help_sidebar' => '',
        'enqueue_webfont'         => true,
        'async_webfont'           => false,
        'output_css'              => true,
        'theme'                   => 'light',
        'class'                   => '',
        'defaults'                => array(),
    ) );
}

// 添加一个POST TYPE
function xyz_add_posttype($name,$slug,$has_tax=true,$posttype_support= array( 'title','thumbnail','comments','editor'),$icon='dashicons-screenoptions',$secret=true){
    $labels = array(
        'name' =>$name,
        'singular_name' =>$name,
        'add_new' => '添加'.$name,
        'add_new_item' => '撰写新'.$name,
        'edit_item' => '编辑'.$name,
        'new_item' => '添加'.$name,
        'view_item' => '查看'.$name,
        'search_items' => '搜索'.$name,
        'not_found' => '未找到'.$name,
        'not_found_in_trash' => '回收站中没有'.$name,
        'all_items' => '所有'.$name,
        'archives' => $name.'存档',
        'insert_into_item' => '插入至'.$name,
        'uploaded_to_this_item' => '上传到本'.$name.'的',
        'featured_image' => '特色图片',
        'set_featured_image' => '设为特色图像',
        'remove_featured_image' => '移除特色图片',
        'use_featured_image' => '作为特色图像',
        'filter_items_list' => '过滤列表',
        'items_list_navigation' => '列表导航',
        'items_list' => $name.'列表',
        'menu_name' => $name,
        'name_admin_bar' => $name
    );
    $args = array(
        'labels'               => $labels,
        'description'          => '',
        'public'               => true,
        'hierarchical'         => true,
        'exclude_from_search'  => false,
        'publicly_queryable'   => $secret,
        'show_ui'              => true,
        'show_in_menu'         => true,
        'show_in_nav_menus'    => true,
        'show_in_admin_bar'    => true,
        'menu_icon'            => $icon,
        'menu_position'        => 7,
        'capability_type'      => 'post',
        'capabilities'         => array(),
        'map_meta_cap'         => null,
        'supports'             => $posttype_support,
        'register_meta_box_cb' => null,
        'taxonomies'           => array(),
        'has_archive'          => true,
        'rewrite'              => true,
        'query_var'            => true,
        'can_export'           => true,
        'delete_with_user'     => null
    );
    register_post_type( $slug, $args);

    if($has_tax){
        $tax_labels = array(
            'name'              => $name.'分类',
            'singular_name'     => $name.'分类',
            'search_items'      => '搜索'.$name.'分类',
            'all_items'         => '所有'.$name.'分类',
            'parent_item'       => '该'.$name.'分类的上级分类',
            'parent_item_colon' => '该'.$name.'分类的上级分类',
            'edit_item'         =>  '编辑'.$name.'分类' ,
            'update_item'       =>  '更新'.$name.'分类' ,
            'add_new_item'      =>  '添加'.$name.'分类' ,
            'new_item_name'     =>  '新'.$name.'分类' ,
            'menu_name'         =>  '分类' ,
        );
        $tax_args = array(
            'labels' => $tax_labels,
            'hierarchical' => true,
        );
        register_taxonomy( $slug.'_tax', $slug, $tax_args );
    }
}

// 添加一个通用POST TYPE
function xyz_add_a_current_post_type($name,$slug,$icon='dashicons-screenoptions'){
    xyz_add_posttype($name,$slug,true,array('title','thumbnail','comments','editor'),$icon,true);
}

// 添加一个只有title的POST TYPE
function xyz_add_a_simple_post_type($name,$slug,$icon='dashicons-screenoptions'){
    xyz_add_posttype($name,$slug,true,array('title'),$icon,true);
}

// 添加一个只有只能后台查看的POST TYPE
function xyz_add_a_secret_post_type($name,$slug,$icon='dashicons-screenoptions'){
    xyz_add_posttype($name,$slug,true,array('title'),$icon,false);
}

function xyz_is_actived(){
    if(get_option('xyz_status')=='actived'){
        return true;
    }else{
        return false;
    }
}
function check_init(){
    $code = $_POST['code'];
    if(!isset($code)){
        $ret['msg'] = '未填写激活码';
        die();
    }
    $args = array(
        'action'=>'check_wx_license',
        'code'=> $code,
    );
    $status = wp_remote_post( 'https://wx.wpxyz.com.cn/wp-admin/admin-ajax.php',array('body'=>$args));

    if ( is_array( $status ) && !is_wp_error($status)) {
        $body = $status['body'];
        $ret['code'] = $status = json_decode($body);

        if($status == 200){
            $ret['msg'] = '验证通过';
            update_option('xyz_status','actived');
        }
        elseif ($status == 402){
            $ret['msg'] = '验证码错误';
        }else{
            $ret['msg'] = '非法请求';
        }

    }else{
        $ret['code'] = 404;
        $ret['msg'] = '远程服务器连接失败';
    }

    echo json_encode( $ret );
    die();

}
add_action('wp_ajax_check_init', 'check_init');
add_action('wp_ajax_nopriv_check_init', 'check_init');


function xyz_plugin_upgrader( $transient ){

    if ( empty($transient->checked ) ) {
        return $transient;
    }

    if( false == $remote = get_transient( 'xyz_upgrade_info' ) ) {

        $args = array(
            'action'=>'get_plugin_info',
            'site'=> get_bloginfo('url'),
            'id'=>'12'
        );
        $remote = wp_remote_post( XYZ_API_URL,array('body'=>$args));

        if ( is_array($remote) && !is_wp_error( $remote ) && isset( $remote['response']['code'] ) && $remote['response']['code'] == 200 && !empty( $remote['body'] ) ) {
            set_transient( 'xyz_upgrade_info', $remote, 60 );
        }

    }

    if( $remote ) {

        $remote = json_decode( $remote['body'] );

        // your installed plugin version should be on the line below! You can obtain it dynamically of course
        if( $remote && version_compare( XYZ_VERSION, $remote->version, '<' ) ) {

            $res = new stdClass();
            $res->slug = 'wpxyz';
            $res->plugin = 'wpxyz/wpxyz.php';
            $res->new_version = $remote->version;
            $res->package = $remote->src;

            $transient->response[$res->plugin] = $res;
        }

    }
    return $transient;
}
add_filter('site_transient_update_plugins', 'xyz_plugin_upgrader' );


function xyz_theme_upgrader($id,$upgrader_url = XYZ_API_URL){

    add_filter('site_transient_update_themes',  function($transient) use($upgrader_url,$id){
        $theme	= get_template();
        if(empty($transient->checked[$theme])){
            return $transient;
        }

        $remote	= get_transient('xyz_theme_upgrade_'.$theme);
        if(false == $remote){
            $args = array(
                'action'=>'get_theme_info',
                'site'=> get_bloginfo('url'),
                'id'=>$id,
            );
            $response = wp_remote_post( $upgrader_url,array('body'=>$args));
            if(is_array($response)){
                $remote = $response['body'];
                $remote = json_decode($remote,true);

                if(!is_wp_error($remote)){
                    set_transient( 'xyz_theme_upgrade_'.$theme, $remote, 120); // 20分钟检测一次更新
                }
            }



        }

        if($remote && !is_wp_error($remote)){
            if(version_compare( $transient->checked[$theme], $remote['new_version'], '<' )){
                $transient->response[$theme]	= $remote;
            }
        }

        return $transient;
    });
}
