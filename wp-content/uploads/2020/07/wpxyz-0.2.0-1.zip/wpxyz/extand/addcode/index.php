<?php
// 防止本文件直接被访问
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if( class_exists( 'CSF' ) && function_exists('xyz_add_submenu')) {


    xyz_add_submenu('添加代码','add_code');
    CSF::createSection( 'add_code', array(
        'fields' => array(
            array(
                'id'       => 'header_code',
                'type'     => 'code_editor',
                'title'    => '头部代码',
                'settings' => array(
                    'theme'  => 'monokai',
                    'mode'   => 'htmlmixed',
                ),
            ),
            array(
                'id'       => 'footer_code',
                'type'     => 'code_editor',
                'title'    => '底部代码',
                'settings' => array(
                    'theme'  => 'monokai',
                    'mode'   => 'htmlmixed',
                ),
            ),


        )
    ) );
    /**
     * 添加代码到头部
     */
    function xyz_add_code_to_header(){
        $addcode = get_option('add_code');
        $code_header = $addcode['header_code'];
        echo $code_header;
    }
    add_action('wp_head', 'xyz_add_code_to_header',2);


    /**
     * 添加代码到底部
     */
    function xyz_add_code_to_footer(){
        $addcode = get_option('add_code');
        $code_footer = $addcode['footer_code'];
        echo $code_footer;
    }
    add_action('wp_footer', 'xyz_add_code_to_footer',2);


}




