<?php
if( class_exists( 'CSF' ) && function_exists('xyz_add_submenu')) {

    // 首页SEO
    xyz_add_submenu('WP优化','wp_switcher');

    CSF::createSection( 'wp_switcher', array(
        'title'  => 'WP优化',
        'fields' => array(

            array(
                'id'            => 'wp_switcher',
                'type'          => 'accordion',
                'accordions'    => array(

                    array(
                        'title'     => '头部优化',
                        'fields'    => array(


                            array(
                                'id'    => 'dnsprefetch_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用s.w.org和dns-prefetch',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                                //  'label'   => 'emoji资源国内不可用，推荐禁用 <a target="_blank" href="https://www.wpxyz.com.cn/wordpress_courese/1.html">了解详情</a>',

                            ),

                            array(
                                'id'    => 'wpgenerator_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用wp_generator',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'wlwmanifest_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用wlwmanifest',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'rsd_link_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用rsd',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'edd_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用edd头部',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'shortlink_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用shortlink',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),
                        )
                    ),
                    array(
                        'title'     => '不常用功能优化',
                        'fields'    => array(

                            array(
                                'id'    => 'emoji_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用emoji',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                                'label'   => 'emoji资源国内不可用，推荐禁用 <a target="_blank" href="https://www.wpxyz.com.cn/wordpress_courese/1.html">了解详情</a>',
                            ),


                            array(
                                'id'    => 'trackbacks_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用Trackbacks',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),


                            array(
                                'id'    => 'XMLRPC_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用 XML-RPC 接口',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),


                            array(
                                'id'    => 'rest_switcher',
                                'type'  => 'switcher',
                                'title' => '屏蔽 REST API',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'oEmbed_switcher',
                                'type'  => 'switcher',
                                'title' => '屏蔽 Auto OEmbed',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'embed_switcher',
                                'type'  => 'switcher',
                                'title' => '屏蔽 文章Embed',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'gtb_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用古腾堡',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),

                            array(
                                'id'    => 'no_self_ping_switcher',
                                'type'  => 'switcher',
                                'title' => '禁用站内ping',
                                'text_on'    => '禁用',
                                'text_off'   => '不禁用',
                            ),




                        )
                    ),
                )
            ),


        )
    ) );

}
