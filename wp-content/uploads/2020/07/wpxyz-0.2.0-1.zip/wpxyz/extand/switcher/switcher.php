<?php
include 'reg_switcher.php';
$wp_switcher = get_option('wp_switcher')['wp_switcher'];

if(is_array($wp_switcher)){

    $emoji_switcher       = $wp_switcher['emoji_switcher']?$wp_switcher['emoji_switcher']:false;
    $dnsprefetch_switcher = $wp_switcher['dnsprefetch_switcher']?$wp_switcher['dnsprefetch_switcher']:false;
    $wpgenerator_switcher = $wp_switcher['wpgenerator_switcher']?$wp_switcher['wpgenerator_switcher']:false;
    $wlwmanifest_switcher = $wp_switcher['wlwmanifest_switcher']?$wp_switcher['wlwmanifest_switcher']:false;
    $rsd_link_switcher    = $wp_switcher['rsd_link_switcher']?$wp_switcher['rsd_link_switcher']:false;
    $gtb_switcher         = $wp_switcher['gtb_switcher']?$wp_switcher['gtb_switcher']:false;
    $edd_switcher         = $wp_switcher['edd_switcher']?$wp_switcher['edd_switcher']:false;
    $shortlink_switcher   = $wp_switcher['shortlink_switcher']?$wp_switcher['shortlink_switcher']:false;
    $webfont_switcher     = $wp_switcher['webfont_switcher']?$wp_switcher['webfont_switcher']:false;
    $no_self_ping_switcher     = $wp_switcher['no_self_ping_switcher ']?$wp_switcher['no_self_ping_switcher ']:false;

// remove wp emoji
if($emoji_switcher){
    remove_action('wp_head', 'print_emoji_detection_script', 7 );
    remove_action('admin_print_scripts','print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
}
//禁止加载s.w.org并移除dns-prefetch
if($dnsprefetch_switcher){

    function xyz_remove_dns_prefetch( $hints, $relation_type ) {
         if ( 'dns-prefetch' === $relation_type ) {
             return array_diff( wp_dependencies_unique_hosts(), $hints );
         }
         return $hints;
     }
    add_filter( 'wp_resource_hints', 'xyz_remove_dns_prefetch', 10, 2 );

}

//remove wp_generator
if($wpgenerator_switcher){
    remove_action('wp_head','wp_generator');
}
//remove wlwmanifest
if($wlwmanifest_switcher) {
    remove_action('wp_head', 'wlwmanifest_link');
}
//removes EditURI/RSD (Really Simple Discovery) link.
if($rsd_link_switcher) {
    remove_action('wp_head', 'rsd_link');
}
//removes edd
if($edd_switcher) {
    remove_action('wp_head', 'edd_version_in_header');
}
if($gtb_switcher){
    // 移除block
    function xyz_remove_block_library_css() {
        wp_dequeue_style( 'wp-block-library' );
    }
    add_action( 'wp_enqueue_scripts', 'xyz_remove_block_library_css', 100 );
//禁用古腾堡编辑器
    add_filter('use_block_editor_for_post', '__return_false');
//屏蔽古腾堡的样式加载
    remove_action( 'wp_enqueue_scripts', 'wp_common_block_scripts_and_styles' );

}

//移除shortlink
if($shortlink_switcher){
    remove_action('wp_head','wp_shortlink_wp_head',10,0);
    remove_action('template_redirect','wp_shortlink_header',11,0);

}

# 清除wp所有自带的customize选项
# ------------------------------------------------------------------------------
function xyz_remove_default_settings_customize( $wp_customize ) {
    $wp_customize->remove_section( 'title_tagline');
    $wp_customize->remove_section( 'colors');
    $wp_customize->remove_section( 'header_image');
    $wp_customize->remove_section( 'background_image');
    $wp_customize->remove_panel( 'nav_menus');
    $wp_customize->remove_section( 'static_front_page');
    $wp_customize->remove_section( 'custom_css');
    $wp_customize->remove_panel( 'widgets' );
}
add_action( 'customize_register', 'xyz_remove_default_settings_customize',50 );


if($webfont_switcher){
    //后台禁止加载谷歌字体
    function xyz_wp_style_del_web( $src, $handle ) {
        if( strpos(strtolower($src),'fonts.googleapis.com') ){
            $src='';
        }
        return $src;
    }
    add_filter( 'style_loader_src', 'xyz_wp_style_del_web', 2, 2 );
//js处理
    function xyz_wp_script_del_web( $src, $handle ) {
        $src_low = strtolower($src);
        if( strpos($src_low,'maps.googleapis.com') ){
            return  str_replace('maps.googleapis.com','ditu.google.cn',$src_low);  //google地图
        }
        if( strpos($src_low,'ajax.googleapis.com') ){
            return  str_replace('ajax.googleapis.com','ajax.useso.com',$src_low);  //google库用360替代
        }
        if( strpos($src_low,'twitter.com') || strpos($src_low,'facebook.com')  || strpos($src_low,'youtube.com') ){
            return '';        //无法访问直接去除
        }
        return $src;
    }
    add_filter( 'script_loader_src', 'xyz_wp_script_del_web', 2, 2 );

}
if($no_self_ping_switcher){
    function no_self_ping( &$links ) {
        $home = get_option( 'home' );
        foreach ( $links as $l => $link )
            if ( 0 === strpos( $link, $home ) )
                unset($links[$l]);
    }
    add_action( 'pre_ping', 'no_self_ping' );
}

}