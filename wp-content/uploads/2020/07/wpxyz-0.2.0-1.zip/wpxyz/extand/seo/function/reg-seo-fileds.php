<?php
// 防止本文件直接被访问
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if( class_exists( 'CSF' ) && function_exists('xyz_add_submenu')) {

    // 首页SEO
    xyz_add_submenu('SEO设置','seo_setting');

    CSF::createSection( 'seo_setting', array(
        'title'  => '首页seo',
        'fields' => array(

            array(
                'id'      => 'custom_title',
                'type'    => 'text',
                'title'   => '自定义首页title',
                'default' =>  get_bloginfo('name').'-'.get_bloginfo('description')
            ),
            array(
                'id'      => 'custom_keywords',
                'type'    => 'textarea',
                'title'   => '自定义首页关键词',
            ),
            array(
                'id'      => 'custom_desc',
                'type'    => 'textarea',
                'title'   => '自定义首页描述',
            ),

        )
    ) );

    // 文章SEO
    CSF::createMetabox( 'single_seo', array(
        'title'          => '小宇宙文章SEO',
        'data_type'      => 'unserialize',
    ));
    CSF::createSection( 'single_seo', array(
        'fields' => array(

            array(
                'id'      => 'custom_title',
                'type'    => 'text',
                'title'   => '自定义title',
            ),
            array(
                'id'      => 'custom_keywords',
                'type'    => 'textarea',
                'title'   => '自定义关键词',
            ),
            array(
                'id'      => 'custom_desc',
                'type'    => 'textarea',
                'title'   => '自定义描述',
            ),

        )
    ) );

    // 页面SEO
    CSF::createMetabox( 'page_seo', array(
        'title'          => '小宇宙页面SEO',
        'data_type'      => 'unserialize',
        'post_type'      => 'page',
    ));
    CSF::createSection( 'page_seo', array(
        'fields' => array(

            array(
                'id'      => 'custom_title',
                'type'    => 'text',
                'title'   => '自定义title',
            ),
            array(
                'id'      => 'custom_keywords',
                'type'    => 'textarea',
                'title'   => '自定义关键词',
            ),
            array(
                'id'      => 'custom_desc',
                'type'    => 'textarea',
                'title'   => '自定义描述',
            ),

        )
    ) );

    // 分类SEO
    CSF::createTaxonomyOptions( 'category_seo', array(
        'taxonomy'  => 'category',
        'data_type' => 'unserialize',
    ) );
    CSF::createSection( 'category_seo', array(
        'fields' => array(

            array(
                'id'      => 'custom_title',
                'type'    => 'text',
                'title'   => '自定义title',
            ),
            array(
                'id'      => 'custom_keywords',
                'type'    => 'textarea',
                'title'   => '自定义关键词',
            ),
            array(
                'id'      => 'custom_desc',
                'type'    => 'textarea',
                'title'   => '自定义描述',
            ),

        )
    ) );

    // 分类SEO
    CSF::createTaxonomyOptions( 'tag_seo', array(
        'taxonomy'  => 'post_tag',
        'data_type' => 'unserialize',
    ) );
    CSF::createSection( 'tag_seo', array(
        'fields' => array(

            array(
                'id'      => 'custom_title',
                'type'    => 'text',
                'title'   => '自定义title',
            ),
            array(
                'id'      => 'custom_keywords',
                'type'    => 'textarea',
                'title'   => '自定义关键词',
            ),
            array(
                'id'      => 'custom_desc',
                'type'    => 'textarea',
                'title'   => '自定义描述',
            ),

        )
    ) );

}




