<?php
// 防止本文件直接被访问
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
// 小宇宙<title>标签输出函数，挂载在wp_head钩子上即可
function xyz_title($sep = '-'){
    if ((is_home() || is_front_page())) {
        $title = get_option('seo_setting')['custom_title'];
        if(!$title){
            $title =  get_bloginfo('name') . '-' . get_bloginfo('description');
        }
    }
    if (is_single()||is_page()) {
        $id =get_the_ID();
        //文章页调用metabox，
        $title = get_post_meta($id,'custom_title',true);
        if(!$title){
            $title = get_the_title() . '-' . get_bloginfo('name');
        }
    }
    if (is_archive()) {
        $title = single_cat_title( '', false ) . '-' . get_bloginfo('name');
        $archive_object = get_queried_object();
        $title = get_term_meta( $archive_object->term_id, 'custom_title', true );
        if(!$title){
            if ( is_category() ) {
                $title = single_cat_title( '', false ) ;
                $title = $title.'-'.get_bloginfo('name') ;
            } elseif ( is_tag() ) {
                $title =  single_tag_title( '', false );
                $title = $title.'-'.get_bloginfo('name') ;
            } elseif ( is_author() ) {
                /* translators: Author archive title. %s: Author name */
                $author =get_the_author();
                $title = '作者：'.$author.'-'.get_bloginfo('name') ;
            }
            elseif ( is_post_type_archive() ) {
                $title = post_type_archive_title( '', false ) .'-'.get_bloginfo('name') ;
            } elseif ( is_tax() ) {
                $title =  single_term_title( '', false ).'-'.get_bloginfo('name') ;
            } elseif(!empty($m)) {

                global $wp_locale;
                $my_year = substr($m, 0, 4);
                $my_month = $wp_locale->get_month(substr($m, 4, 2));
                $my_day = intval(substr($m, 6, 2));

                // If there's a year
                if (is_archive() && !empty($year)) {
                    $title = $year;

                    if (!empty($monthnum)) {
                        $title .= $sep . $wp_locale->get_month($monthnum);
                    }
                    if (!empty($day)) {
                        $title .= $sep . zeroise($day, 2);
                    }
                }
                // If it's a search
                if (is_search()) {
                    /* translators: 1: separator, 2: search phrase */
                    $search = get_query_var('s');
                    $title = sprintf(__('搜索：'), strip_tags($search));
                }

                // If it's a 404 page
                if (is_404()) {
                    $title = '404错误！页面未找到';
                }
            }
        }
    }
    // If there's a month
    echo "<title>$title</title>";
    echo "\n";

}

// 小宇宙keywords信息输出函数，输出name="keywords"的meta头
function xyz_keywords(){
$sep = ',';
        // 设置网站基础关键词
        //
        $keywords_base = get_option('seo_setting')['custom_keywords'];

        // 如若未填写基础关键词，则调用网站名称为基础关键词
        if(!$keywords_base){
            $keywords_base= get_bloginfo('name');
        }

    //首页直接调用基础关键词
    if((is_home() || is_front_page())) {
        $keywords= $keywords_base;
    }

    if (is_single()||is_page()) {

        $id =get_the_ID();
        //文章页调用metabox，
        $keywords = get_post_meta($id,'custom_keywords',true);

        //如果metabox未填写则调用所有分类和所有tag
        if(!$keywords ){

            $keywords = get_the_title();

            if(!is_page()){
                $category_array = get_the_category($id) ;
                if(is_array($category_array)){
                    foreach ($category_array as $category){
                        $keywords.= $sep.$category->cat_name;
                    }
                }
                $tags_array = get_the_tags($id) ;
                if(is_array($tags_array)){
                    foreach ($tags_array as $tags){
                        $keywords.= $sep.$category->name;
                    }
                }

            }

        }

    }
    if (is_archive()) {

        $archive_object = get_queried_object();
        $keywords = get_term_meta( $archive_object->term_id, 'custom_keywords', true );
        if(!$keywords){
            $keywords = single_cat_title( '', false ) .$sep. $keywords_base ;
        }

    }
    // If there's a month
    if (is_archive() && !empty($m)) {

        global $wp_locale;
        $my_year = substr($m, 0, 4);
        $my_month = $wp_locale->get_month(substr($m, 4, 2));
        $my_day = intval(substr($m, 6, 2));

        // If there's a year
        if (is_archive() && !empty($year)) {
            $keywords =  $keywords_base;
            if (!empty($monthnum)) {
                $keywords = $year.'年'.$wp_locale->get_month($monthnum).'月' .$sep.$keywords_base;
            }
            if (!empty($day)) {
                $keywords = $year.'年'.$wp_locale->get_month($monthnum).'月'. zeroise($day, 2).'日'.$sep.$keywords_base ;
            }
        }
        // If it's a search
        if (is_search()) {
            /* translators: 1: separator, 2: search phrase */
            $search = get_query_var('s');
            $keywords = strip_tags($search).$sep.$keywords_base;
        }
        // If it's a 404 page
        if (is_404()) {
            $keywords = '404'.$sep.$keywords_base;
        }
    }
	$keywords_array =  explode(',',$keywords);
	$keywords_array_unique = array_unique($keywords_array);
	$keywords = implode($sep,$keywords_array_unique);

    echo '<meta name="keywords" content="'.$keywords.'" />';
    echo "\n";


}

// 小宇宙description信息输出函数，输出name="description"的meta头
function xyz_desc(){
    if((is_home() || is_front_page())) {
        $desc  = get_option('seo_setting')['custom_desc'];
        if(!$desc){
            $desc=get_bloginfo( 'description' );
        }
    }
    if (is_single()||is_page()) {
        $id =get_the_ID();
        //文章页调用metabox，
        $desc = get_post_meta($id,'custom_desc',true);
        if(!$desc){
            $desc = get_the_excerpt($id);
        }
    }
    if (is_archive()) {
        $archive_object = get_queried_object();
        $desc = get_term_meta( $archive_object->term_id, 'custom_desc', true );
        if(!$desc){
            if ( is_category() ) {
                /* translators: Category archive title. %s: Category name */
                $title = single_cat_title( '', false ) ;
                $desc = '这是'.get_bloginfo('name').'网站的《'.$title. '》分类' ;

            } elseif ( is_tag() ) {
                /* translators: Tag archive title. %s: Tag name */
                $title =  single_tag_title( '', false );
                $desc = '这是'.get_bloginfo('name').'网站的《'.$title. '》标签' ;
            } elseif ( is_author() ) {
                /* translators: Author archive title. %s: Author name */
                $author =get_the_author();
                $desc = '这是'.$author.'发布再'.get_bloginfo('name').'网站的文章' ;
            }
        }
    }
    // If there's a month
    if (is_archive() && !empty($m)) {

        global $wp_locale;
        $my_year = substr($m, 0, 4);
        $my_month = $wp_locale->get_month(substr($m, 4, 2));
        $my_day = intval(substr($m, 6, 2));

        // If there's a year
        if (is_archive() && !empty($year)) {
            $desc = '这是'.get_bloginfo('name').'网站'.$year.'年的文章列表' ;
            if (!empty($monthnum)) {
                $desc = '这是'.get_bloginfo('name').'网站'.$year.'年'.$wp_locale->get_month($monthnum).'月的文章列表' ;
            }
            if (!empty($day)) {
                $desc = '这是'.get_bloginfo('name').'网站'.$year.'年'.$wp_locale->get_month($monthnum).'月'. zeroise($day, 2).'日的文章列表' ;
            }
        }
        // If it's a search
        if (is_search()) {
            /* translators: 1: separator, 2: search phrase */
            $search = get_query_var('s');
            $desc = '这是'.get_bloginfo('name').'网站搜索'.strip_tags($search).'的结果';
        }
        // If it's a 404 page
        if (is_404()) {
            $desc = '404错误！页面未找到';
        }
    }
    echo '<meta name="description" content="'.$desc.'" />';
    echo "\n";

}


add_action('wp_head', 'xyz_title',1);
add_action('wp_head', 'xyz_keywords',1);
add_action('wp_head', 'xyz_desc',1);
