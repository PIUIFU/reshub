<?php
# 注册SEO选项
include 'function/reg-seo-fileds.php';

# SEO功能
include 'function/functions.php';

