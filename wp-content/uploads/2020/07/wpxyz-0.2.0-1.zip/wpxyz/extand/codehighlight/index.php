<?php

function pure_highlightjs_admin_init() {
    static $inited = false;

    if ( $inited ) {
        return;
    }

    register_setting( 'pure-highlightjs-group', 'pure-highlightjs-theme' );

    load_plugin_textdomain( 'pure-highlightjs', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );

    $inited = true;
}
add_action( 'admin_init', 'pure_highlightjs_admin_init' );


function pure_highlightjs_action_links( $links, $file ) {
    if ( $file == plugin_basename( __FILE__ ) ) {
        $links[] = '<a href="' . esc_url( pure_highlightjs_get_page_url() ) . '">' . esc_html__( 'Settings' , 'pure-highlightjs') . '</a>';
    }

    return $links;
}

add_filter( 'plugin_action_links', 'pure_highlightjs_action_links', 10, 2 );


add_action( 'wp_enqueue_scripts', 'pure_highlightjs_assets' );

function pure_highlightjs_assets() {
      $style = pure_highlightjs_get_style_list()[get_option('hightlight')['style']] ;
      if(empty($style)){
          $style = 'monokai';
      }
    wp_enqueue_style( 'pure-highlightjs-style', XYZ_STATIC_URL .'highlight/styles/' .$style. '.css', array(), '0.9.2' );
    wp_enqueue_script( 'pure-highlightjs-pack', XYZ_STATIC_URL . 'highlight/highlight.pack.js', array(), '0.9.2', true );
}

add_action( 'admin_enqueue_scripts', 'pure_highlightjs_admin_assets' );

function pure_highlightjs_admin_assets() {
    global $hook_suffix;

    if ( in_array( $hook_suffix, array(
        'index.php', # dashboard
        'post.php',
        'post-new.php',
        'settings_page_pure-highlightjs-config',
    ) ) ) {
        wp_enqueue_script( 'pure-highlightjs', XYZ_JS_URL . 'pure-highlight.js', array(), '0.1.0', true );

        wp_enqueue_script( 'pure-highlightjs-pack', XYZ_STATIC_URL . 'highlight/highlight.pack.js', array(), '0.9.2', true );

        wp_localize_script( 'pure-highlightjs', 'PureHighlightjsTrans', array(
            'title' => '添加代码',
            'language' =>  '代码语言',
            'code' => '代码',
        ));
    }
}

// load tinyMCE pure-highlightjs plugin
add_filter('mce_external_plugins', 'pure_highlightjs_mce_plugin');

function pure_highlightjs_mce_plugin( $mce_plugins ) {
    $mce_plugins['purehighlightjs'] = XYZ_JS_URL . 'tinymce.js';
    return $mce_plugins;
}

add_filter( 'mce_css', 'pure_highlightjs_mce_css');

function pure_highlightjs_mce_css( $mce_css ) {
    if (! is_array($mce_css) ) {
        $mce_css = explode(',', $mce_css);
    }

    $mce_css[] = XYZ_CSS_URL . 'tinymce.css';

    return implode( ',', $mce_css );
}

add_filter('mce_buttons', 'pure_highlightjs_mce_buttons', 101);

function pure_highlightjs_mce_buttons( $buttons ) {
    if (! in_array('PureHighlightjsInsert', $buttons) ){
        $buttons[] = 'PureHighlightjsInsert';
    }
    return $buttons;
}

function pure_highlightjs_get_style_list($theme = '') {
    $path = XYZ_PATH.'/static/highlight/styles/';
    $themes = array();
    foreach (new DirectoryIterator($path) as $fileInfo) {
        if ($fileInfo->isDot() || ! $fileInfo->isFile()) {
            continue;
        }

        $filename = $fileInfo->getFilename();

        if ('.css' != substr($filename, -4)) {
            continue;
        }

        $style_name = substr($filename, 0, - 4);

        array_push($themes,$style_name);

    }

    sort($themes);

    return $themes;
}

xyz_add_submenu('代码高亮','hightlight');
CSF::createSection( 'hightlight', array(
    'fields' => array(

        array(
            'id'          => 'style',
            'type'        => 'select',
            'title'       => '选择代码高亮风格',
            'options'     => pure_highlightjs_get_style_list(),
            'default'     => 'monokai'
        ),

    )
) );
