<?php
// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    CSF::createShortcoder( 'src', array(
        'button_title' => '插入资源',
        'insert_title' => '插入资源',
    ) );
    CSF::createSection( 'src', array(
        'title'     => '免费资源',
        'shortcode' => 'freesrc',
        'fields'    => array(

            array(
                'id'    => 'srctitle',
                'type'  => 'text',
                'title' => '文件标题',
            ),
            array(
                'id'    => 'srcdesc',
                'type'  => 'text',
                'title' => '文件描述',
            ),
            array(
                'id'      => 'srcurl',
                'type'    => 'media',
                'title'   => '上传资源',
                'preview' => false,
            ),

        )
    ) );

}

function free_src($atts) {

    $srctitle = $atts['srctitle'];
    $srcdesc = $atts['srcdesc'];
    $srcurl = $atts['url'];

    $return = "<div class='uk-padding uk-padding-remove-vertical'><div class=\"file_download uk-background-muted uk-grid-stack\" uk-grid>
         <div class=\"uk-width-auto uk-padding-remove\">
             <div class=\"uk-background-primary\">
                 <svg class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2179\" width=\"30\" height=\"30\"><path d=\"M256 85.333333a85.333333 85.333333 0 0 0-85.333333 85.333334v682.666666a85.333333 85.333333 0 0 0 85.333333 85.333334h512a85.333333 85.333333 0 0 0 85.333333-85.333334V341.333333l-256-256H256m0 85.333334h298.666667v213.333333h213.333333v469.333333H256V170.666667m85.333333 341.333333v85.333333h341.333334v-85.333333H341.333333m0 170.666667v85.333333h213.333334v-85.333333H341.333333z\" fill=\"#ffffff\" p-id=\"2180\"></path></svg>
             </div>
         </div>
         <div class=\"uk-width-expand uk-padding-small uk-padding-remove-top\">
             <h3 class=\"title uk-h4 uk-margin-remove-bottom \">";
    $return .= $srctitle ;
    $return .="</h3>
             <div class=\"subtitle uk-text-meta\">
                 <small>";
    $return .=  $srcdesc;
    $return .= "</small>
             </div>
         </div>
         <div class=\"uk-width-auto\">
             <a href=\"";
    $return .=$srcurl;
    $return .="\">
                 <svg class=\"icon\" viewBox=\"0 0 1092 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2118\" width=\"18\" height=\"18\"><path d=\"M1044.753067 902.3488H47.5136a47.5136 47.5136 0 0 0 0 94.890667h997.239467a45.806933 45.806933 0 0 0 33.5872-13.858134 47.5136 47.5136 0 0 0-33.5872-81.032533z m-522.4448-103.970133a33.450667 33.450667 0 0 0 23.825066 8.874666 33.450667 33.450667 0 0 0 23.825067-8.874666l302.2848-290.952534c7.509333-7.236267 8.874667-16.452267 3.6864-24.7808-5.188267-8.3968-32.768-7.714133-44.8512-7.714133h-118.784V47.5136c0-25.941333-13.789867-47.5136-47.445333-47.5136H427.4176c-33.655467 0-47.5136 21.572267-47.5136 47.5136v427.349333H237.431467c-12.014933 0-15.906133-0.6144-21.162667 7.7824-5.188267 8.328533-3.754667 17.544533 3.6864 24.7808l302.421333 290.952534z\" fill=\"#448ef6\" p-id=\"2119\"></path></svg>
             </a>
         </div>
     </div>
     </div>";
    return $return;

}
add_shortcode('freesrc', 'free_src');
