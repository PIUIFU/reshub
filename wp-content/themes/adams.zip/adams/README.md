# Adams

一套适用于 WordPress 的简洁、轻量的 Theme
![](https://wx1.sinaimg.cn/large/76679337ly1gcj1k23yf7j219r0u00wf.jpg)

# 发行

Github 默认为开发版，如果需要稳定发行版，请前往：https://github.com/Tokinx/Adams/releases

下载后进入 WordPress 后台进行安装并启用即可

主题设置项在：后台 -> 主题 -> 自定义

# 如何贡献

合理的改动的PR都会被合并，合理的 issues 都会被采纳并修改。

# 鸣谢

维护：[Tokin](https://biji.io)

贡献：[@Frank](https://github.com/w4o)、[@Abdul Wahab](https://github.com/abdulwahab610)、[@Sammy Liang](https://github.com/SammyLiang97)、[@刘明野](https://github.com/liumingye)、[@lizhimiao](https://github.com/zhimiaoli)、[@keinx](https://github.com/keinx)

# 讨论

https://github.com/Tokinx/Adams/issues
